import { Center, Text } from "@mantine/core";

function Botttombar(){
    return (
        <Center h={42} py={26} bg='#e9edff' style={{ position: "fixed", bottom: 0, width: "100%" }}>
            <Text color='black'><b>GOVERNMENT</b></Text>
        </Center>
    )
}

export default Botttombar;